import createHistory from 'history/createBrowserHistory'

export default createHistory()
