export const AUTH_CONFIG = {
  domain: 'mrksihna2025.auth0.com',
  clientId: 'fVh1dR6aje0950DZRmCdXFseb2SmJIZk',
  callbackUrl: 'http://localhost:3000/callback'
}
